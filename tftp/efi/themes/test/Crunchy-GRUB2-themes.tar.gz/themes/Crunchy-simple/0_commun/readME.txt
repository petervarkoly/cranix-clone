Theses folders are for different colors of selection.

These themes are named 'simple' because they don't need any translated setting file.

The fonts can't be moved elsewhere. They have to be in the same folder as the theme-....txt files.
